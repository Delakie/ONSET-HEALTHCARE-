// Onset Healthcare — shared site behaviour

document.addEventListener('DOMContentLoaded', () => {

  // Footer year
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Mobile nav toggle
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const open = navLinks.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // Service tabs (home page)
  const tabs = document.querySelectorAll('.tab-btn');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.setAttribute('aria-selected', 'false'));
      tab.setAttribute('aria-selected', 'true');
      document.querySelectorAll('.tabpanel').forEach(p => p.removeAttribute('data-active'));
      const panel = document.getElementById(tab.getAttribute('aria-controls'));
      if (panel) panel.setAttribute('data-active', 'true');
    });
  });

  // Scroll reveal
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('in'));
  }

  // Jump to booking form if URL has #book, and focus first field
  if (window.location.hash === '#book') {
    const bookCard = document.getElementById('book');
    if (bookCard) {
      setTimeout(() => {
        bookCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
        const firstField = document.getElementById('fullName');
        if (firstField) firstField.focus();
      }, 150);
    }
  }

  // Booking form — submits to Formspree (no server of our own needed).
  // The <form> action attribute holds the Formspree endpoint; set it once
  // in contact.html (action="https://formspree.io/f/YOUR_FORM_ID").
  const bookingForm = document.getElementById('bookingForm');
  const confirmCard = document.getElementById('confirmCard');
  const bookSubmitBtn = document.getElementById('bookSubmitBtn');
  const bookError = document.getElementById('bookError');

  if (bookingForm && confirmCard) {
    bookingForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!bookingForm.checkValidity()) {
        bookingForm.reportValidity();
        return;
      }

      const name = document.getElementById('fullName').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const service = document.getElementById('service').value;

      if (bookError) bookError.style.display = 'none';
      if (bookSubmitBtn) {
        bookSubmitBtn.disabled = true;
        bookSubmitBtn.textContent = 'Sending...';
      }

      try {
        const response = await fetch(bookingForm.action, {
          method: 'POST',
          body: new FormData(bookingForm),
          headers: { Accept: 'application/json' }
        });

        if (!response.ok) throw new Error('Submission failed');

        const confirmName = document.getElementById('confirmName');
        const confirmService = document.getElementById('confirmService');
        const confirmPhone = document.getElementById('confirmPhone');
        if (confirmName) confirmName.textContent = name || 'there';
        if (confirmService) confirmService.textContent = service || 'your visit';
        if (confirmPhone) confirmPhone.textContent = phone;

        bookingForm.style.display = 'none';
        confirmCard.setAttribute('data-show', 'true');

        const seal = document.getElementById('confirmSeal');
        if (seal) {
          seal.classList.remove('play');
          void seal.offsetWidth; // restart animation
          seal.classList.add('play');
        }
        confirmCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } catch (err) {
        if (bookError) bookError.style.display = 'block';
        if (bookSubmitBtn) {
          bookSubmitBtn.disabled = false;
          bookSubmitBtn.textContent = 'Submit request';
        }
      }
    });
  }

  // Hero stamp plays once on load
  const heroSeal = document.getElementById('heroSeal');
  if (heroSeal) {
    requestAnimationFrame(() => heroSeal.classList.add('play'));
  }

  // Animated vitals background — a scrolling heartbeat trace with a
  // pulse that beeps in sync, plus a few slow drifting plus/capsule
  // glyphs. Used behind the hero and page-head bands.
  document.querySelectorAll('.vital-bg').forEach(initVitalBackground);
});

function initVitalBackground(canvas) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);

  const cs = getComputedStyle(document.documentElement);
  const primary = (cs.getPropertyValue('--primary') || '#1226E8').trim();
  const accent = (cs.getPropertyValue('--accent') || '#D81B5E').trim();

  function hexToRgba(hex, a) {
    hex = hex.replace('#', '');
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    return `rgba(${r},${g},${b},${a})`;
  }

  let width = 0, height = 0;
  function resize() {
    const rect = canvas.parentElement.getBoundingClientRect();
    width = rect.width; height = rect.height;
    canvas.width = Math.max(1, width * dpr);
    canvas.height = Math.max(1, height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resize();
  window.addEventListener('resize', resize);

  // Heartbeat waveform, defined as [fraction-of-period, fraction-of-amplitude]
  const ecgPoints = [
    [0.00, 0], [0.14, 0], [0.18, 0.12], [0.22, 0], [0.30, 0],
    [0.33, -0.12], [0.365, 1], [0.40, -0.35], [0.44, 0],
    [0.56, 0], [0.62, 0.22], [0.70, 0], [1.00, 0]
  ];
  function ecgFrac(t) {
    for (let i = 0; i < ecgPoints.length - 1; i++) {
      const [t0, v0] = ecgPoints[i], [t1, v1] = ecgPoints[i + 1];
      if (t >= t0 && t <= t1) {
        const f = (t - t0) / (t1 - t0 || 1);
        return v0 + (v1 - v0) * f;
      }
    }
    return 0;
  }

  const period = 240;
  const amplitude = 24;
  const speed = reduceMotion ? 0 : 0.9;
  let offset = 0;
  const pulseXFrac = 0.74;
  let pulses = [];
  let lastBeatFrame = -999;

  function makeDrifter(initial) {
    return {
      x: Math.random() * width,
      y: initial ? Math.random() * height : height + 20,
      size: 7 + Math.random() * 9,
      speed: 0.12 + Math.random() * 0.22,
      sway: 6 + Math.random() * 10,
      phase: Math.random() * Math.PI * 2,
      type: Math.random() < 0.6 ? 'plus' : 'capsule',
      alpha: 0.07 + Math.random() * 0.09
    };
  }
  let drifters = [];
  for (let i = 0; i < 9; i++) drifters.push(makeDrifter(true));

  function drawPlus(x, y, s, alpha, color) {
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1.4, s * 0.22);
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x - s, y); ctx.lineTo(x + s, y);
    ctx.moveTo(x, y - s); ctx.lineTo(x, y + s);
    ctx.stroke();
  }
  function drawCapsule(x, y, s, alpha, color) {
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1.2, s * 0.16);
    ctx.beginPath();
    ctx.ellipse(x, y, s * 1.15, s * 0.55, Math.PI / 4, 0, Math.PI * 2);
    ctx.stroke();
  }

  let frame = 0;
  function draw() {
    ctx.clearRect(0, 0, width, height);
    const baselineY = height * 0.62;

    // scrolling heartbeat trace
    offset = (offset + speed) % period;
    ctx.beginPath();
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = hexToRgba(primary, 0.32);
    let started = false;
    for (let x = -period; x <= width + period; x += 3) {
      const localT = (((x - offset) % period) + period) % period / period;
      const y = baselineY - ecgFrac(localT) * amplitude;
      if (!started) { ctx.moveTo(x, y); started = true; } else { ctx.lineTo(x, y); }
    }
    ctx.stroke();

    // pulse ring synced to the trace's R-spike crossing a fixed point
    const targetX = width * pulseXFrac;
    const localTAtTarget = (((targetX - offset) % period) + period) % period / period;
    if (!reduceMotion && Math.abs(localTAtTarget - 0.365) < 0.012 && frame - lastBeatFrame > 30) {
      pulses.push({ x: targetX, y: baselineY - amplitude, r: 2, alpha: 0.55 });
      lastBeatFrame = frame;
    }
    pulses.forEach(p => { p.r += 1.1; p.alpha -= 0.012; });
    pulses = pulses.filter(p => p.alpha > 0.02);
    pulses.forEach(p => {
      ctx.globalAlpha = 1;
      ctx.beginPath();
      ctx.strokeStyle = hexToRgba(accent, Math.max(p.alpha, 0));
      ctx.lineWidth = 2;
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.stroke();
    });
    ctx.globalAlpha = 1;
    ctx.beginPath();
    ctx.fillStyle = hexToRgba(accent, 0.5);
    ctx.arc(targetX, baselineY - amplitude, 2.4, 0, Math.PI * 2);
    ctx.fill();

    // slow drifting plus / capsule glyphs
    drifters.forEach(d => {
      d.y -= d.speed * (reduceMotion ? 0 : 1);
      const sway = Math.sin(frame * 0.02 + d.phase) * d.sway * 0.3;
      const dx = d.x + sway;
      if (d.type === 'plus') drawPlus(dx, d.y, d.size, d.alpha, primary);
      else drawCapsule(dx, d.y, d.size, d.alpha, accent);
      if (d.y < -20) Object.assign(d, makeDrifter(false));
    });
    ctx.globalAlpha = 1;

    frame++;
    if (!reduceMotion) requestAnimationFrame(draw);
  }
  requestAnimationFrame(draw);
}
